const { Router } = require("express");
const router = Router();
const controller = require("../../controllers/Team/team");

router.get("/all_team", controller.getTeam);
router.get("/team", controller.getTeamByAdmin);
router.get("/team/:id", controller.getTeamByID);
router.post("/team/add", controller.createTeam);
router.put("/team/edit/:id", controller.editTeam);
router.put("/team/change_password/:id", controller.ChangeTeamPassword);
router.delete("/team/delete/:id", controller.deleteTeam);

module.exports = router;
