const { Router } = require("express");
const router = Router();
const controller = require("../../controllers/projects/project");

router.get("/all_project", controller.getProject);
router.get("/project", controller.getProjectByAdmin);
router.get("/project/:id", controller.getProjectByID);
router.post("/project/add", controller.createProject);
router.put("/project/edit/:id", controller.editProject);
router.delete("/project/delete/:id", controller.deleteProject);

module.exports = router;
