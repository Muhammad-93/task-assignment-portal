const { Router } = require("express");
const router = Router();
const controller = require("../../controllers/Task/task");

router.get("/project/task/:id", controller.getTaskByProjectID);
router.get("/project/task_detail/:id", controller.getProjectTaskByID);
router.post("/project/task/add", controller.createTask);
router.put("/project/task/edit/:id", controller.editTask);
router.put("/project/task/edit_status/:id", controller.editTaskStatus);
router.delete("/project/task/delete/:id", controller.deleteTask);

module.exports = router;
