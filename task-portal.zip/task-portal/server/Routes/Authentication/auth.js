const { Router } = require("express");
const router = Router();
const controller = require("../../controllers/Authentication/auth");

router.get("/auth/admin", controller.getAdmin);
router.post("/auth/admin/register", controller.registerAdmin);
router.post("/auth/admin/login", controller.loginAdmin);

module.exports = router;
