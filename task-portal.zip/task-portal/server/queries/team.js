const fetchTeam = "SELECT * FROM team";
const fetchTeamByAdmin = "SELECT * FROM team WHERE admin_id = $1";
const fetchTeamById = "SELECT * FROM team WHERE id = $1 AND admin_id= $2";

const addTeam =
  "INSERT INTO team (name,email,password,confirmPassword,role,admin_id) VALUES ($1, $2, $3, $4, $5,$6)";
const checkEmailExist = "SELECT s FROM team s WHERE s.email = $1";
const updateTeam =
  "UPDATE team SET name = $1,email=$2,role=$3 WHERE id = $4 AND admin_id=$5";
const changePassword =
  "UPDATE team SET password = $1,confirmPassword=$2 WHERE id = $3 AND admin_id=$4";
const removeTeam = "DELETE FROM team WHERE id = $1";
const checkIDExist = "SELECT s FROM team s WHERE s.id = $1";
const teamLogin = "SELECT * FROM team WHERE email = $1";

module.exports = {
  fetchTeam,
  fetchTeamById,
  addTeam,
  checkEmailExist,
  checkIDExist,
  changePassword,
  teamLogin,
  fetchTeamByAdmin,
  updateTeam,
  removeTeam,
};
