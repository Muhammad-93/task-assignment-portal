const fetchTask = "SELECT * FROM task";
const fetchTaskByProject =
  "SELECT * FROM task WHERE project_id = $1 AND admin_id = $2";

const fetchTaskById = "SELECT * FROM task WHERE task_id = $1 AND admin_id= $2";

const addTask =
  "INSERT INTO task (name,description,status,project_id,team_id,admin_id) VALUES ($1,$2, $3,$4,$5,$6)";
const checkIDExist = "SELECT s FROM projects s WHERE s.id = $1";
const checkTaskIDExist = "SELECT s FROM task s WHERE s.task_id = $1";
const updateTask =
  "UPDATE task SET  name= $1,description= $2,status= $3,team_id=$4  WHERE project_id = $5 AND task_id = $6";

const updateTaskStatus =
  "UPDATE task SET status= $1 WHERE project_id = $2 AND task_id = $3";

const removeTask = "DELETE FROM task WHERE task_id = $1";

module.exports = {
  fetchTask,
  fetchTaskByProject,
  checkIDExist,
  fetchTaskById,
  checkTaskIDExist,
  updateTaskStatus,
  addTask,
  updateTask,
  removeTask,
};
