const fetchAdmin = "SELECT * FROM admin";
const adminLogin = "SELECT * FROM admin WHERE email = $1";

const adminRegister =
  "INSERT INTO admin (name,email,pass,con_pass) VALUES ($1, $2, $3, $4)";
const checkEmailExist = "SELECT s FROM admin s WHERE s.email = $1";
module.exports = {
  fetchAdmin,
  adminLogin,
  adminRegister,
  checkEmailExist,
};
