const fetchProject = "SELECT * FROM projects";
const fetchProjectByAdmin = "SELECT * FROM projects WHERE admin_id = $1";
const fetchProjectById =
  "SELECT * FROM projects WHERE id = $1 AND admin_id= $2";

const addProject =
  "INSERT INTO projects (project_name, description, start_date,end_date,team_members, admin_id) VALUES ($1, $2, $3,$4, $5,$6)";
const checkIDExist = "SELECT s FROM projects s WHERE s.id = $1";
const updateProject =
  "UPDATE projects SET project_name = $1, description= $2,start_date=$3,end_date=$4, team_members=$5  WHERE id = $7 AND admin_id=$6";
const removeProject = "DELETE FROM projects WHERE id = $1";
module.exports = {
  fetchProject,
  fetchProjectByAdmin,
  fetchProjectById,
  addProject,
  checkIDExist,
  updateProject,
  removeProject,
};
