const express = require("express");
var cors = require("cors");
const client = require("./connection");
const app = express();
const auth = require("./Routes/Authentication/auth");
const team = require("./Routes/Team/team");
const project = require("./Routes/Project/project");
const task = require("./Routes/Task/task");

// const port = process.env.PORT || 5000;

app.use(express.json());
// const corsOptions = {
//   origin: "http://localhost:3000",
//   credentials: true, //access-control-allow-credentials:true
//   optionSuccessStatus: 200,
// };
// app.use(cors(corsOptions));
app.use(cors());
// app.use(function (req, res, next) {
//   res.header("Access-Control-Allow-Origin", "*");
//   res.header("Access-Control-Allow-Methods", "*");
//   res.header("Access-Control-Allow-Headers", "*");
//   next();
// });
app.use(auth);
app.use(team);
app.use(project);
app.use(task);

const server = app.listen(process.env.PORT || 5000, () => {
  const port = server.address().port;
  console.log(`connection successfull at ${port}`);
});

client.connect();
