const { Client } = require("pg");

// const client = new Client({
//   host: "localhost",
//   user: "postgres",
//   port: 5432,
//   password: "12345",
//   database: "taskportal",
// });

const client = new Client({
  host: "ec2-54-144-237-73.compute-1.amazonaws.com",
  user: "flbtmmqezewets",
  port: 5432,
  password: "7f0e22dcab1c729291cf430f01bb0b3e5d90c193c256258fe7e4f1426cae087d",
  database: "dddo60n0v9kns1",
  ssl: {
    rejectUnauthorized: false,
  },
});

module.exports = client;
