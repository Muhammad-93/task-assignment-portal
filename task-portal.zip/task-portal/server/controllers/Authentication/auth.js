const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const client = require("../../connection");
const queries = require("../../queries/auth");

const getAdmin = (req, res) => {
  // res.send("fetch admin");
  client.query(queries.fetchAdmin, (err, result) => {
    if (err) throw err;
    res.status(200).json({ code: 200, message: result.rows });
  });
};

const loginAdmin = (req, res) => {
  // res.send("fetch admin");
  console.log(req.body, "login data");
  const email = req.body.email;
  const password = req.body.pass;
  if (email !== "" && password !== "") {
    client.query(queries.adminLogin, [email], async (err, result) => {
      if (err) {
        throw err;
      } else {
        console.log(result.rows, "result result of login");
        const isPasswordValid = await bcrypt.compare(
          password,
          result.rows[0].pass
        );
        if (isPasswordValid) {
          const token = jwt.sign(
            {
              id: result.rows[0].id,
            },
            "secret123"
          );
          res.status(200).json({
            code: 200,
            message: "login succesfully",
            admin: {
              id: result.rows[0].id,
              name: result.rows[0].name,
              email: result.rows[0].email,
            },
            token: token,
          });
        } else {
          res.status(404).json({
            code: 404,
            message: "invalid credentials",
          });
        }
      }
    });
  } else {
    return res.send({ message: "please fill all fields" });
  }
};

const registerAdmin = (req, res) => {
  // res.send("admin created");
  const { name, email, pass, con_pass } = req.body;
  console.log(req.body);
  if (name !== "" && email !== "" && pass !== "" && con_pass !== "") {
    client.query(queries.checkEmailExist, [email], async (err, result) => {
      console.log(result, "email exist or not");
      if (result.rows.length) {
        res.send({ message: "Email already exists." });
      } else {
        const password = await bcrypt.hash(pass, 10);
        const confirmPassword = await bcrypt.hash(con_pass, 10);

        client.query(
          queries.adminRegister,
          [name, email, password, password],
          (error, result) => {
            if (error) throw error;

            client.query(queries.adminLogin, [email], async (err, result) => {
              if (err) {
                throw err;
              } else {
                console.log(result, "register rows");
                const token = jwt.sign(
                  {
                    id: result.rows[0].id,
                  },
                  "secret123"
                );
                res.status(200).json({
                  code: 200,
                  message: "Admin created successfully",
                  admin: {
                    id: result.rows[0].id,
                    name: result.rows[0].name,
                    email: result.rows[0].email,
                  },
                  token: token,
                });
              }
            });
          }
        );
      }
    });
  } else {
    return res.send({ message: "please fill all fields" });
  }
};

module.exports = {
  getAdmin,
  loginAdmin,
  registerAdmin,
};
