const jwt = require("jsonwebtoken");
const client = require("../../connection");
const queries = require("../../queries/project");

const getProject = (req, res) => {
  // res.send("fetch admin");
  client.query(queries.fetchProject, (err, result) => {
    if (err) throw err;
    res.status(200).json({ code: 200, message: result.rows });
  });
};

const getProjectByAdmin = (req, res) => {
  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  client.query(queries.fetchProjectByAdmin, [decoded.id], (err, result) => {
    if (err) throw err;
    console.log(result, "result");
    res.status(200).json({ code: 200, project: result.rows });
  });
};

const getProjectByID = (req, res) => {
  // res.send("fetch admin");

  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  client.query(queries.checkIDExist, [id], (err, result) => {
    console.log(result, "id exist or not");
    if (!result.rows.length) {
      res.send({ message: "project not exists." });
    } else {
      client.query(
        queries.fetchProjectById,
        [id, decoded.id],
        (err, result) => {
          if (err) throw err;
          console.log(result, "result");
          res.status(200).json({ code: 200, project: result.rows });
        }
      );
    }
  });
};

const createProject = (req, res) => {
  // res.send("team created");
  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  console.log(req.body, "login data");
  const { project_name, description, start_date, end_date, team_members } =
    req.body;
  if (project_name !== "" && start_date !== "" && end_date !== "") {
    client.query(
      queries.addProject,
      [
        project_name,
        description,
        start_date,
        end_date,
        team_members,
        decoded.id,
      ],
      (error, result) => {
        if (error) throw error;
        res.status(200).json({
          code: 200,
          message: "project added successfully",
        });
      }
    );
  } else {
    return res.send({ message: "please fill all fields" });
  }
};

const editProject = (req, res) => {
  // res.send("team updated");
  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  const { project_name, description, start_date, end_date, team_members } =
    req.body;
  console.log(req.body);
  client.query(queries.fetchProjectById, [id, decoded.id], (err, result) => {
    if (err) throw err;
    const noProjectFound = !result.rows.length;
    if (noProjectFound) {
      res.status(200).json({ message: "project does not exist" });
    } else {
      if (project_name !== "" && start_date !== "" && end_date !== "") {
        client.query(
          queries.updateProject,
          [
            project_name,
            description,
            start_date,
            end_date,
            team_members,
            decoded.id,
            id,
          ],
          (error, result) => {
            if (error) throw error;
            res.status(200).json({
              code: 200,
              message: "project updated successfully",
            });
          }
        );
      } else {
        return res.send({ message: "please fill all fields" });
      }
    }
  });
};

const deleteProject = (req, res) => {
  // res.send("team deleted");
  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  client.query(queries.fetchProjectById, [id, decoded.id], (err, result) => {
    if (err) throw err;
    const noProjectFound = !result.rows.length;
    if (noProjectFound) {
      res.status(200).json({ message: "project does not exist" });
    } else {
      client.query(queries.removeProject, [id], (err, result) => {
        if (err) throw err;
        res
          .status(200)
          .json({ code: 200, message: "project deleted successfully" });
      });
    }
  });
};

module.exports = {
  getProject,
  editProject,
  getProjectByID,
  getProjectByAdmin,
  createProject,
  deleteProject,
};
