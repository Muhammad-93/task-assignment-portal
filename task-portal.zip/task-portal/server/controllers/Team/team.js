const jwt = require("jsonwebtoken");
const client = require("../../connection");
const queries = require("../../queries/team");

const getTeam = (req, res) => {
  // res.send("fetch admin");
  client.query(queries.fetchTeam, (err, result) => {
    if (err) throw err;
    res.status(200).json({ code: 200, team: result.rows });
  });
};

const getTeamByAdmin = (req, res) => {
  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  client.query(queries.fetchTeamByAdmin, [decoded.id], (err, result) => {
    if (err) throw err;
    console.log(result, "result");
    res.status(200).json({ code: 200, team: result.rows });
  });
};

const getTeamByID = (req, res) => {
  // res.send("fetch admin");
  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  client.query(queries.checkIDExist, [id], (err, result) => {
    console.log(result, "email exist or not");
    if (!result.rows.length) {
      res.send({ message: "team member not exists." });
    } else {
      client.query(queries.fetchTeamById, [id, decoded.id], (err, result) => {
        if (err) throw err;
        console.log(result, "result");
        res.status(200).json({ code: 200, team: result.rows });
      });
    }
  });
};

const createTeam = (req, res) => {
  // res.send("team created");
  console.log(req.body, "login data");

  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const { email, name, password, confirmPassword, role } = req.body;
  if (email !== "" && name !== "" && role !== "") {
    client.query(queries.checkEmailExist, [email], (err, result) => {
      console.log(result, "email exist or not");
      if (result.rows.length) {
        res.send({ message: "Email already exists." });
      } else {
        client.query(
          queries.addTeam,
          [name, email, password, confirmPassword, role, decoded.id],
          (error, result) => {
            if (error) throw error;
            res.status(200).json({
              code: 200,
              message: "team member added successfully",
            });
          }
        );
      }
    });
  } else {
    return res.send({ message: "please fill all fields" });
  }
};

const editTeam = (req, res) => {
  // res.send("team updated");

  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  const { name, email, role } = req.body;
  console.log(req.body);
  client.query(queries.fetchTeamById, [id, decoded.id], (err, result) => {
    if (err) throw err;
    const noTeamFound = !result.rows.length;
    if (noTeamFound) {
      res.status(200).json({ message: "team member does not exist" });
    } else {
      if (name !== "" && email !== "" && role !== "") {
        client.query(
          queries.updateTeam,
          [name, email, role, id, decoded.id],
          (error, result) => {
            if (error)
              throw res.json({
                message: error.detail,
              });
            res.status(200).json({
              code: 200,
              message: "team member updated successfully",
            });
          }
        );
      } else {
        return res.send({ message: "please fill all fields" });
      }
    }
  });
};

const ChangeTeamPassword = (req, res) => {
  // res.send("team updated");

  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  const { password, confirmPassword } = req.body;
  console.log(req.body);
  client.query(queries.fetchTeamById, [id, decoded.id], (err, result) => {
    if (err) throw err;
    const noTeamFound = !result.rows.length;
    if (noTeamFound) {
      res.status(200).json({ message: "team member does not exist" });
    } else {
      if (password !== "" && confirmPassword !== "") {
        client.query(
          queries.changePassword,
          [password, confirmPassword, id, decoded.id],
          (error, result) => {
            if (error)
              throw res.json({
                message: error.detail,
              });
            res.status(200).json({
              code: 200,
              message: "team member password updated successfully",
            });
          }
        );
      } else {
        return res.send({ message: "please fill all fields" });
      }
    }
  });
};

const deleteTeam = (req, res) => {
  // res.send("team deleted");
  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  client.query(queries.fetchTeamById, [id, decoded.id], (err, result) => {
    if (err) throw err;
    const noTeamFound = !result.rows.length;
    if (noTeamFound) {
      res.status(200).json({ message: "team member does not exist" });
    } else {
      client.query(queries.removeTeam, [id], (err, result) => {
        if (err) throw err;
        res
          .status(200)
          .json({ code: 200, message: "team member deleted successfully" });
      });
    }
  });
};

module.exports = {
  getTeam,
  getTeamByAdmin,
  editTeam,
  getTeamByID,
  createTeam,
  ChangeTeamPassword,
  deleteTeam,
};
