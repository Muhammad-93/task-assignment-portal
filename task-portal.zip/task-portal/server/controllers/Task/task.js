const jwt = require("jsonwebtoken");
const client = require("../../connection");
const queries = require("../../queries/task");

const getTaskByProjectID = (req, res) => {
  // res.send("fetch admin");
  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  client.query(queries.checkIDExist, [id], (err, result) => {
    if (!result.rows.length) {
      res.send({ message: "project not exists." });
    } else {
      client.query(
        queries.fetchTaskByProject,
        [id, decoded.id],
        (err, result) => {
          if (err) throw err;
          console.log(result, "result");
          res.status(200).json({ code: 200, task: result.rows });
        }
      );
    }
  });
};

const getProjectTaskByID = (req, res) => {
  // res.send("fetch admin");

  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  client.query(queries.checkTaskIDExist, [id], (err, result) => {
    console.log(result, "id exist or not");
    if (!result.rows.length) {
      res.send({ message: "task not exists." });
    } else {
      client.query(queries.fetchTaskById, [id, decoded.id], (err, result) => {
        if (err) throw err;
        console.log(result, "result");
        res.status(200).json({ code: 200, project: result.rows });
      });
    }
  });
};

const createTask = (req, res) => {
  // res.send("team created");
  console.log(req.body, "login data");

  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const { name, description, status, project_id, team_id } = req.body;
  if (name !== "") {
    client.query(
      queries.addTask,
      [name, description, status, project_id, team_id, decoded.id],
      (error, result) => {
        if (error) throw error;
        res.status(200).json({
          code: 200,
          message: "task added successfully",
        });
      }
    );
  } else {
    return res.send({ message: "dont empty all fields" });
  }
};

const editTask = (req, res) => {
  // res.send("team updated");

  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  const { name, description, status, team_id, project_id } = req.body;
  console.log(req.body);
  client.query(queries.fetchTaskById, [id, decoded.id], (err, result) => {
    if (err) throw err;
    const noTeamFound = !result.rows.length;
    if (noTeamFound) {
      res.status(200).json({ message: "task does not exist" });
    } else {
      if (name !== "") {
        client.query(
          queries.updateTask,
          [name, description, status, team_id, project_id, id],
          (error, result) => {
            if (error)
              throw res.json({
                message: error.detail,
              });
            res.status(200).json({
              code: 200,
              message: "task updated successfully",
            });
          }
        );
      } else {
        return res.send({ message: "dont empty all fields" });
      }
    }
  });
};

const editTaskStatus = (req, res) => {
  // res.send("team updated");

  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  const { status, project_id } = req.body;
  console.log(req.body);
  client.query(queries.fetchTaskById, [id, decoded.id], (err, result) => {
    if (err) throw err;
    const noTeamFound = !result.rows.length;
    if (noTeamFound) {
      res.status(200).json({ message: "task does not exist" });
    } else {
      if (status !== "") {
        client.query(
          queries.updateTaskStatus,
          [status, project_id, id],
          (error, result) => {
            if (error)
              throw res.json({
                message: error.detail,
              });
            res.status(200).json({
              code: 200,
              message: "task status updated successfully",
            });
          }
        );
      } else {
        return res.send({ message: "dont empty all fields" });
      }
    }
  });
};

const deleteTask = (req, res) => {
  // res.send("team deleted");
  const token = req.header("Authorization");
  const decoded = jwt.verify(token, "secret123");
  const id = parseInt(req.params.id);
  client.query(queries.fetchTaskById, [id, decoded.id], (err, result) => {
    if (err) throw err;
    const noTeamFound = !result.rows.length;
    if (noTeamFound) {
      res.status(200).json({ message: "task does not exist" });
    } else {
      client.query(queries.removeTask, [id], (err, result) => {
        if (err) throw err;
        res
          .status(200)
          .json({ code: 200, message: "task deleted successfully" });
      });
    }
  });
};

module.exports = {
  editTask,
  getTaskByProjectID,
  getProjectTaskByID,
  editTaskStatus,
  createTask,
  deleteTask,
};
