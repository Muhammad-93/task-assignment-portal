### v1.2.0

###### Sep 18, 2021

- Support MIU v5.0.0 official release
- Upgrade some dependencies to the latest versions

###### Aug 18, 2021

- Update `src/theme/typography.js`
- Upgrade some dependencies to the latest versions

---

### v1.1.0

###### Jul 23, 2021

- Support MUI v5.0.0-beta.1
- Upgrade some dependencies to the latest versions

---

### v1.0.0

###### Jun 28, 2021

Initial release.
