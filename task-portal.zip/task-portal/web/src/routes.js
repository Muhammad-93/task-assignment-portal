import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import LogoOnlyLayout from "./layouts/LogoOnlyLayout";
import DashboardLayout from "./layouts/dashboard";
import {
  DashboardApp,
  Team,
  Project,
  TaskListing,
  AddProject,
  AddTeam,
  EditTeam,
  EditProject,
} from "./pages";
import NotFound from "./pages/Page404";
import Login from "./pages/Login";
import Register from "./pages/Register";
const Authentication = () => {
  if (localStorage.getItem("token")) {
    return <Navigate to="/dashboard"> </Navigate>;
  }
  if (!localStorage.getItem("token")) {
    return <Navigate to="/login"> </Navigate>;
  }
};
export default function Router() {
  return (
    <Routes>
      <Route element={<DashboardLayout />}>
        <Route path="/" element={<Authentication />} />
        <Route path="/dashboard" element={<DashboardApp />} />
        <Route path="/project" element={<Project />} />
        <Route path="/project/task/:id" element={<TaskListing />} />
        <Route path="/project/add_project" element={<AddProject />} />
        <Route path="/project/edit_project/:id" element={<EditProject />} />
        <Route path="/team/add_team" element={<AddTeam />} />
        <Route path="/team/edit_team/:id" element={<EditTeam />} />
        <Route path="/team" element={<Team />} />
      </Route>
      <Route element={<LogoOnlyLayout />}>
        <Route path="/" element={<Authentication />} />
        <Route path="/register" element={<Register />} />
        <Route path="404" element={<NotFound />} />
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
