import {
  Container,
  Button,
  Grid,
  IconButton,
  Typography,
  TextField,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useSnackbar } from "notistack";
import { useNavigate, useParams } from "react-router-dom";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { edit_team, team_detail } from "../../DAL/Team";

export default function EditTeam() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { enqueueSnackbar } = useSnackbar();
  const Team = { name: "", email: "", phone: "", department: "", role: "" };
  const [addteam, setaddTeam] = useState(Team);
  const handleChange = (e) => {
    setaddTeam({ ...addteam, [e.target.name]: e.target.value });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(addteam, "inputs");
    const postData = {
      name: addteam.name,
      email: addteam.email,
      role: addteam.role,
    };
    const result = await edit_team(postData, id);
    if (result.code === 200) {
      navigate(-1);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
    }
  };

  const detailTeam = async () => {
    const result = await team_detail(id);
    if (result.code === 200) {
      console.log(result, "team detail");
      setaddTeam({
        ...addteam,
        name: result.team[0].name,
        email: result.team[0].email,
        role: result.team[0].role,
      });
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
    }
  };

  useEffect(() => {
    detailTeam();
  }, []);
  return (
    <Container maxWidth="sm">
      <IconButton onClick={() => navigate(-1)}>
        <ArrowBackIcon />
      </IconButton>

      <Typography textAlign="center" variant="h4">
        Edit Team{" "}
      </Typography>
      <form onSubmit={handleSubmit}>
        <Grid spacing={2} container>
          <Grid item xs={12}>
            <TextField
              autoFocus
              fullWidth
              required
              margin="dense"
              name="name"
              label="Name"
              type="text"
              variant="outlined"
              value={addteam.name}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              margin="dense"
              name="email"
              required
              label="Email Address"
              type="text"
              variant="outlined"
              value={addteam.email}
              onChange={handleChange}
            />
          </Grid>
          {/* <Grid item xs={12}>
            <TextField
              fullWidth
              margin="dense"
              name="phone"
              label="Phone Number"
              type="text"
              variant="outlined"
              value={addteam.phone}
              onChange={handleChange}
            />
          </Grid> */}
          <Grid item xs={12}>
            <TextField
              fullWidth
              margin="dense"
              name="role"
              required
              label="Role"
              type="text"
              variant="outlined"
              value={addteam.role}
              onChange={handleChange}
            />
          </Grid>
          <Grid mt={2} item xs={12} style={{ textAlign: "center" }}>
            <Button variant="contained" type="submit">
              Update
            </Button>
            <Button
              variant="contained"
              type="submit"
              className="ms-2"
              color="error"
              onClick={() => navigate("/team")}
            >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </form>
    </Container>
  );
}
