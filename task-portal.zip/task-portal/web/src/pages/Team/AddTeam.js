import {
  Container,
  Button,
  Grid,
  IconButton,
  Typography,
  TextField,
} from "@mui/material";
import React, { useState } from "react";
import { useSnackbar } from "notistack";
import { useNavigate, useParams } from "react-router-dom";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { add_team } from "../../DAL/Team";

export default function AddTeam() {
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const Team = {
    name: "",
    email: "",
    phone: "",
    department: "",
    role: "",
    password: "",
    confirmPassword: "",
  };
  const [addteam, setaddTeam] = useState(Team);
  const handleChange = (e) => {
    setaddTeam({ ...addteam, [e.target.name]: e.target.value });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(addteam, "inputs");
    if (addteam.password !== addteam.confirmPassword) {
      enqueueSnackbar("Password and confirm Password does not matched", {
        variant: "error",
      });
      return;
    }
    console.log(addteam, "inputs");
    const postData = {
      name: addteam.name,
      email: addteam.email,
      role: addteam.role,
      password: addteam.password,
      confirmPassword: addteam.confirmPassword,
    };
    const result = await add_team(postData);
    if (result.code === 200) {
      navigate(-1);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
    }
  };
  return (
    <Container maxWidth="sm">
      <IconButton onClick={() => navigate(-1)}>
        <ArrowBackIcon />
      </IconButton>

      <Typography textAlign="center" variant="h4">
        Add Team{" "}
      </Typography>
      <form onSubmit={handleSubmit}>
        <Grid spacing={2} container>
          <Grid item xs={12}>
            <TextField
              autoFocus
              fullWidth
              required
              margin="dense"
              name="name"
              label="Name"
              type="text"
              variant="outlined"
              value={addteam.name}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              margin="dense"
              required
              name="email"
              label="Email Address"
              type="text"
              variant="outlined"
              value={addteam.email}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              margin="dense"
              required
              name="password"
              label="Password"
              type="password"
              variant="outlined"
              value={addteam.password}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              margin="dense"
              name="confirmPassword"
              required
              label="Confirm Password"
              type="password"
              variant="outlined"
              value={addteam.confirmPassword}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              margin="dense"
              name="phone"
              label="Phone Number"
              type="text"
              variant="outlined"
              value={addteam.phone}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              margin="dense"
              name="role"
              label="Role"
              required
              type="text"
              variant="outlined"
              value={addteam.role}
              onChange={handleChange}
            />
          </Grid>
          <Grid mt={2} item xs={12} style={{ textAlign: "center" }}>
            <Button variant="contained" type="submit">
              Add Team
            </Button>
          </Grid>
        </Grid>
      </form>
    </Container>
  );
}
