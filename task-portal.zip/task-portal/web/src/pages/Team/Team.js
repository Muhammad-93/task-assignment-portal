import {
  Container,
  TableContainer,
  TablePagination,
  TableBody,
  TableRow,
  TableCell,
  Card,
  Table,
  Box,
  Stack,
  Typography,
  CircularProgress,
} from "@mui/material";
import { Link, Link as RouterLink, useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";
import Button from "@mui/material/Button";
import { makeStyles } from "@mui/styles";
import { useSnackbar } from "notistack";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogTitle from "@mui/material/DialogTitle";
import Scrollbar from "../../components/Scrollbar";
import {
  TeamListHead,
  TeamListToolbar,
  TeamMoreMenu,
} from "../../components/_dashboard/team";
import { team_listing, delete_team } from "../../DAL/Team";
const team_head = [
  {
    name: "Name",
    email: "EmailAdress",
    role: "Role",
    actionButton: "Action",
  },
];

const useStyles = makeStyles((theme) => ({
  hed: {
    fontWeight: "bold",
  },
  clmwdth: {
    width: "10px",
  },
  root: {
    "&:hover": {
      backgroundColor: "transparent",
    },
  },
  btnadd: {
    float: "right",
    color: "white",
    fontSize: "15px",
  },
  mnu: {
    cursor: "pointer",
  },
  modal: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  paper: {
    backgroundColor: "white",
    height: "70%",
    overflowY: "auto",
  },
}));

export default function Team() {
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const classes = useStyles();
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [rowData, setRowData] = useState({});
  const [loading, setLoading] = useState(true);
  const [team, setTeam] = useState([]);
  const [opendialog, setOpenDialog] = React.useState(false);

  const handleOpenDialog = (data) => {
    setOpenDialog(true);
    setRowData(data);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const deleteTeam = async (id) => {
    setLoading(true);
    const result = await delete_team(id);
    if (result.code === 200) {
      getTeamListing();
      handleCloseDialog();
      setLoading(false);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
      setLoading(false);
    }
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const getTeamListing = async () => {
    const result = await team_listing();
    console.log(result.team);
    if (result.code === 200) {
      setTeam(result.team);
      setLoading(false);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
      setLoading(false);
    }
  };

  useEffect(() => {
    getTeamListing();
  }, []);

  if (loading) {
    return <CircularProgress style={{ marginLeft: "50%", marginTop: "20%" }} />;
  }

  // return focus to the button when we transitioned from !open -> open

  return (
    <Container>
      <Stack direction="row" justifyContent="space-between" mb={3}>
        <Box>
          <Typography variant="h4">Team</Typography>
        </Box>
        <Button variant="contained" onClick={() => navigate("/team/add_team")}>
          Add Team
        </Button>
      </Stack>

      <Stack mt={2} mb={3}>
        <Card>
          <TeamListToolbar label="Team" />

          <Scrollbar>
            <TableContainer sx={{ minWidth: 800 }}>
              <Table>
                <TeamListHead headLabel={team_head} />
                <TableBody>
                  {team.length > 0
                    ? team.map((member, index) => (
                        <TableRow hover style={{ cursor: "pointer" }}>
                          <TableCell>{member.name}</TableCell>
                          <TableCell>{member.email}</TableCell>
                          <TableCell>{member.role}</TableCell>
                          <TableCell>
                            <TableCell align="right">
                              <TeamMoreMenu
                                onOpenDeleteDialog={handleOpenDialog}
                                isUserData={member}
                              />
                            </TableCell>
                          </TableCell>
                        </TableRow>
                      ))
                    : "No Data Found"}
                </TableBody>
              </Table>
            </TableContainer>
          </Scrollbar>
          {/* <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={2}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          /> */}
        </Card>
      </Stack>
      <Dialog open={opendialog} onClose={handleCloseDialog}>
        <DialogTitle>
          Are you sure you want to delete this team member ?
        </DialogTitle>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button onClick={() => deleteTeam(rowData.id)}>Yes, Delete</Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}
