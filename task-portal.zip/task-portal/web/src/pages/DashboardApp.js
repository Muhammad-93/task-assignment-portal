// material
import React, { useState, useEffect } from "react";
import {
  Box,
  Grid,
  Container,
  Typography,
  CircularProgress,
} from "@mui/material";
// components
import Page from "../components/Page";
import { TotalTeam, TotalProject } from "../components/_dashboard/app";

import { project_listing } from "../DAL/Project";
import { team_listing } from "../DAL/Team";
// ----------------------------------------------------------------------

export default function DashboardApp() {
  const [projectCount, setProjectCount] = React.useState();
  const [teamCount, setTeamCount] = React.useState();
  const [loading, setLoading] = useState(true);

  const getProjectListing = async () => {
    const result = await project_listing();
    if (result.code === 200) {
      console.log(result.project.length, "result.project.length");
      setProjectCount(result.project.length);
      setLoading(false);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
      setLoading(false);
    }
  };

  const getTeamListing = async () => {
    const result = await team_listing();
    console.log(result.team);
    if (result.code === 200) {
      setTeamCount(result.team.length);
      setLoading(false);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
      setLoading(false);
    }
  };

  useEffect(() => {
    getProjectListing();
    getTeamListing();
  }, []);

  if (loading) {
    return <CircularProgress style={{ marginLeft: "50%", marginTop: "20%" }} />;
  }

  return (
    // <Page title="Dashboard | Minimal-UI">
    <Container maxWidth="xl">
      <Box sx={{ pb: 5 }}>
        <Typography variant="h4">
          Hi, {localStorage.getItem("name")} Welcome back
        </Typography>
      </Box>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={3}>
          <TotalTeam teamCount={teamCount} />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <TotalProject projectCount={projectCount} />
        </Grid>
      </Grid>
    </Container>
    // </Page>
  );
}
