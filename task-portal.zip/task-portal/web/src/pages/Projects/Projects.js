import React, { useEffect, useState } from "react";
import { useSnackbar } from "notistack";
// material
import { Link as RouterLink, useNavigate } from "react-router-dom";
// material
import {
  Stack,
  Button,
  Container,
  Typography,
  Grid,
  CircularProgress,
} from "@mui/material";

// components
import { ProjectCards } from "../../components/_dashboard/project";
import { project_listing, delete_project } from "../../DAL/Project";
// ----------------------------------------------------------------------

// ----------------------------------------------------------------------

export default function Project() {
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);

  const deleteProject = async (id) => {
    setLoading(true);
    const result = await delete_project(id);
    if (result.code === 200) {
      getProjectListing();
      setLoading(false);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
      setLoading(false);
    }
  };

  const getProjectListing = async () => {
    const result = await project_listing();
    if (result.code === 200) {
      setData(result.project);
      setLoading(false);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
      setLoading(false);
    }
  };

  useEffect(() => {
    getProjectListing();
  }, []);

  if (loading) {
    return <CircularProgress style={{ marginLeft: "50%", marginTop: "20%" }} />;
  }

  return (
    <Container>
      <Stack direction="row" justifyContent="space-between" mb={3}>
        <Typography variant="h4">Projects</Typography>
        <Button
          variant="contained"
          onClick={() => navigate("/project/add_project")}
        >
          Add Project
        </Button>
      </Stack>

      <Grid container spacing={4}>
        {data.length > 0 ? (
          data.map((project, index) => (
            <Grid item xs={4}>
              <ProjectCards project={project} deleteProject={deleteProject} />
            </Grid>
          ))
        ) : (
          <Grid item xs={12} style={{ textAlign: "center" }}>
            <h3>No Data Found</h3>
          </Grid>
        )}
      </Grid>
    </Container>
  );
}
