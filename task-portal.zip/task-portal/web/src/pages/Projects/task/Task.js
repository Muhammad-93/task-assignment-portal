import * as React from "react";
// import { useFormik } from 'formik';
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { useState, useRef } from "react";
import PropTypes from "prop-types";
import { Icon } from "@iconify/react";
import editFill from "@iconify/icons-eva/edit-fill";
import trash2Outline from "@iconify/icons-eva/trash-2-outline";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
// material
import { alpha, styled } from "@mui/material/styles";
import CircularProgress from "@mui/material/CircularProgress";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import KeyboardArrowDownOutlinedIcon from "@mui/icons-material/KeyboardArrowDownOutlined";
import { useSnackbar } from "notistack";
import {
  Container,
  Stack,
  Typography,
  Avatar,
  Button,
  MenuItem,
  ListItem,
  List,
  ListItemIcon,
  ListItemText,
  IconButton,
  Popover,
  Box,
  AvatarGroup,
} from "@mui/material";
import TextField from "@mui/material/TextField";
import Divider from "@mui/material/Divider";
import Checkbox from "@mui/material/Checkbox";
import moment from "moment";
import CircleIcon from "@mui/icons-material/Circle";
import Dialog from "@mui/material/Dialog";
import Paper from "@mui/material/Paper";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import HighlightOffIcon from "@mui/icons-material/HighlightOff";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import DatePicker from "react-datepicker";
import AddIcon from "@mui/icons-material/Add";
import DragIndicatorIcon from "@mui/icons-material/DragIndicator";
import PanToolIcon from "@mui/icons-material/PanTool";
import Tooltip from "@mui/material/Tooltip";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { Menu } from "@szhsin/react-menu";
import "@szhsin/react-menu/dist/index.css";
import Sekeleton from "../../../components/Sekeleton";
import { noTask } from "../../../assets";
import {
  add_task,
  task_listing,
  delete_task,
  edit_task,
} from "../../../DAL/Task";
import AddTask from "../../../components/_dashboard/task/AddTask";
import { team_listing } from "../../../DAL/Team";
import EditTask from "../../../components/_dashboard/task/EditTask";
// components
// ----------------------------------------------------------------------

const ArrowStyle = styled("span")(({ theme }) => ({
  [theme.breakpoints.up("sm")]: {
    top: -7,
    zIndex: 1,
    width: 12,
    right: 20,
    height: 12,
    content: "''",
    position: "absolute",
    borderRadius: "0 0 4px 0",
    transform: "rotate(-135deg)",
    background: theme.palette.background.paper,
    borderRight: `solid 1px ${alpha(theme.palette.grey[500], 0.12)}`,
    borderBottom: `solid 1px ${alpha(theme.palette.grey[500], 0.12)}`,
  },
}));

CircularProgressWithLabel.propTypes = {
  value: PropTypes.number.isRequired,
};

function CircularProgressWithLabel(props) {
  return (
    <Box
      sx={{
        position: "relative",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <CircularProgress
        variant="determinate"
        {...props}
        style={{ height: 35, width: 35 }}
      />
      <Tooltip title="Progress">
        <Box
          sx={{
            top: 0,
            left: 0,
            bottom: 0,
            right: 0,
            position: "absolute",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
            border: "1px solid #c5c5c5",
            borderRadius: "50%",
          }}
        >
          <Typography variant="caption" component="div" color="text.secondary">
            {`${Math.round(props.value)}%`}
          </Typography>
        </Box>
      </Tooltip>
    </Box>
  );
}

export default function TaskListing(props) {
  const navigate = useNavigate();
  const { id } = useParams();
  const anchortotalMember = useRef(null);
  const { enqueueSnackbar } = useSnackbar();
  const location = useLocation();
  const [projectStats, setProjectStats] = useState({
    all: 0,
    pending: 0,
    completed: 0,
  });
  const [openTotalMemberListing, setOpenTotalMemberListing] = useState(false);
  const [taskdata, setTaskData] = React.useState([]);
  const [rowData, setRowData] = React.useState({});
  const [team, setTeam] = useState([]);
  const [iswaiting, setIswaiting] = useState(true);
  const [openAddDialog, setOpenAddDialog] = useState(false);
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);

  console.log(location);

  const getStatusColor = (status) => {
    if (status === "Complete") {
      return "green";
    }
    if (status === "Pending") {
      return "blue";
    }
    if (status === "Approve") {
      return "grey";
    }
  };

  const handleopenDeleteDialog = (data) => {
    console.log(data, "dialog data");
    setOpenDeleteDialog(true);
    setRowData(data);
  };

  const handleopenAddDialog = () => {
    setOpenAddDialog(true);
  };
  const handleopenEditDialog = (data) => {
    setOpenEditDialog(true);
    setRowData(data);
  };
  const handleCloseDialog = () => {
    setOpenAddDialog(false);
    setOpenDeleteDialog(false);
    setOpenEditDialog(false);
  };

  const handleClose = (id) => {
    setOpenTotalMemberListing(false);
  };

  const handleOpenTotalMemberListing = () => {
    setOpenTotalMemberListing(true);
  };

  const handleAddTask = async (data) => {
    console.log(data, "data recived");
    const postData = {
      name: data.name,
      description: data.description,
      status: data.status,
      team_id: data.members,
      project_id: id,
    };
    const result = await add_task(postData);
    if (result.code === 200) {
      handleCloseDialog();
      getTaskListing();
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
      setIswaiting(false);
    }
  };

  const handleEditTask = async (data, task_id) => {
    console.log(data, "data recived");
    const postData = {
      name: data.name,
      description: data.description,
      status: data.status,
      team_id: data.members,
      project_id: id,
    };
    const result = await edit_task(postData, task_id);
    if (result.code === 200) {
      handleCloseDialog();
      getTaskListing();
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
      setIswaiting(false);
    }
  };

  const handleDeleteTask = async (task_id) => {
    console.log(task_id, "deleted data recived");

    const result = await delete_task(task_id);
    if (result.code === 200) {
      handleCloseDialog();
      getTaskListing();
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
      setIswaiting(false);
    }
  };

  const handleVisibleDetail = (status, id) => {
    console.log(status);
    setTaskData((task) =>
      task.map((x) => {
        if (x.task_id === id) {
          return {
            ...x,
            detailVisible: status,
          };
        }
        return x;
      })
    );
  };

  const assignee = (data) => {
    console.log(data, "get assignee");
    let assigneees;
    team.map((x, i) => {
      if (x.id === data) {
        assigneees = x.name;
      }
    });
    return assigneees
      ? "Assign to : " + assigneees
      : "Task is not assign to any team member";
  };

  const getTeamListing = async () => {
    const result = await team_listing();
    console.log(result.team);
    if (result.code === 200) {
      setTeam(result.team);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
    }
  };

  const getTaskListing = async () => {
    const result = await task_listing(id);
    console.log(result, "tasks");
    if (result.code === 200) {
      const tasks = result.task.map((x, i) => {
        return {
          task_id: x.task_id,
          task: x.name,
          status: x.status,
          detailVisible: false,
          members: x.team_id,
          description: x.description,
        };
      });
      setTaskData(tasks);
      setIswaiting(false);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
      setIswaiting(false);
    }
  };

  React.useEffect(() => {
    getTaskListing();
    getTeamListing();
  }, []);

  const calculateTaskStats = () => {
    const all = taskdata.length;
    let completed = 0;
    let pending = 0;
    taskdata.forEach((task) => {
      if (String(task.status) === "Complete") {
        completed += 1;
      }
    });
    pending = all - completed;

    setProjectStats({ all, pending, completed });
  };

  React.useEffect(() => {
    calculateTaskStats();
  }, [taskdata]);

  return (
    // <Page title="Tasks | Task Portal">
    <Container style={{ backgroundColor: "#fff" }}>
      <div className="row main-header">
        <div
          className="col-lg-4 col-md-12 col-sm-12 pl-0 align-items-center"
          style={{ display: "flex" }}
        >
          <IconButton onClick={() => navigate(-1)}>
            <ArrowBackIcon />
          </IconButton>
          <Tooltip title="Project Name">
            <Typography
              style={{ fontsize: 16, fontWeight: "bold", paddingLeft: 8 }}
            >
              {location.state !== null && location.state.project_name}
            </Typography>
          </Tooltip>
        </div>

        <div className="col-lg-3 col-md-6 col-sm-12 header-date">
          <Tooltip title="Start Date - End Date">
            <Typography
              sx={{ cursor: "pointer", fontSize: 12 }}
              className="date-css"
            >
              {moment(location.state.start_date).format("DD MMM, YYYY")} -{" "}
              {moment(location.state.end_date).format("DD MMM, YYYY")}
            </Typography>
          </Tooltip>
        </div>
        <div className="col-lg-3 col-md-6 col-sm-12 header-task">
          <Typography
            sx={{ cursor: "default", fontSize: 12 }}
            className="date-css"
          >
            Pending&nbsp;
          </Typography>
          <Tooltip title="Pending Task">
            <div
              className="status-circle"
              style={{
                backgroundColor: "#3366FF",
              }}
            >
              <Typography sx={{ cursor: "default", fontSize: 12 }}>
                {projectStats.pending}
              </Typography>
            </div>
          </Tooltip>
          <Typography
            sx={{ cursor: "default", fontSize: 12 }}
            className="date-css"
          >
            &nbsp;Complete&nbsp;
          </Typography>
          <Tooltip title="Completed Task">
            <div
              className="status-circle"
              style={{
                backgroundColor: "#00AB55",
              }}
            >
              <Typography
                sx={{
                  cursor: "default",
                  fontSize: 12,
                }}
              >
                {projectStats.completed}
              </Typography>
            </div>
          </Tooltip>
          <Typography
            sx={{
              cursor: "default",
              fontSize: 12,
            }}
            className="date-css"
          >
            &nbsp;Total&nbsp;
          </Typography>
          <Tooltip title="Total Task">
            <div
              className="status-circle"
              style={{
                backgroundColor: "#c5c5c5",
              }}
            >
              <Typography
                sx={{
                  cursor: "default",
                  fontSize: 12,
                }}
              >
                {projectStats.all}
              </Typography>
            </div>
          </Tooltip>
        </div>
        <div className="col-lg-2 col-md-12 col-sm-12 header-progress">
          <CircularProgressWithLabel
            value={
              projectStats.completed !== 0 && projectStats.all !== 0
                ? (projectStats.completed / projectStats.all) * 100
                : 0
            }
          />
          <Tooltip title="Team Members">
            <AvatarGroup
              max={3}
              style={{ cursor: "pointer" }}
              ref={anchortotalMember}
              onClick={() => handleOpenTotalMemberListing(true)}
            >
              {location.state.team_members.length > 0 &&
                location.state.team_members.map((x, i) => {
                  let member = JSON.parse(x);
                  return (
                    <>
                      <Avatar style={{ width: 30, height: 30 }}>
                        {member.name.substring(0, 1)}
                      </Avatar>
                    </>
                  );
                })}
            </AvatarGroup>
          </Tooltip>
          <Popover
            open={openTotalMemberListing}
            onClose={() => handleClose()}
            anchorEl={anchortotalMember.current}
            anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
            transformOrigin={{ vertical: "top", horizontal: "right" }}
            PaperProps={{
              sx: {
                mt: 1.5,
                ml: 0.5,
                width: 230,
                height: 280,
                overflow: "auto",
                boxShadow: (theme) => theme.customShadows.z20,
                border: (theme) => `solid 1px ${theme.palette.grey[500_8]}`,
              },
            }}
          >
            <ArrowStyle className="arrow" />
            <List>
              <ListItem>
                <ListItemText primary="Team Members" />
              </ListItem>
              {location.state.team_members.length > 0
                ? location.state.team_members.map((x, i) => {
                    let member = JSON.parse(x);
                    return (
                      <>
                        <ListItem>
                          <ListItemIcon>
                            <Avatar
                              alt="Remy Sharp"
                              style={{ height: 30, width: 30 }}
                            >
                              {member.name.substring(0, 1)}
                            </Avatar>
                          </ListItemIcon>
                          <ListItemText>{member.name}</ListItemText>
                        </ListItem>
                      </>
                    );
                  })
                : ""}
            </List>
          </Popover>
        </div>
      </div>

      <div
        className="mt-3"
        style={{
          display: "flex",
          border: "1px dashed black",
          width: "100%",
          padding: 15,
          borderRadius: 10,
        }}
        role="button"
        tabIndex="0"
        onClick={() => handleopenAddDialog()}
        onKeyDown={() => handleopenAddDialog()}
      >
        <AddIcon style={{ color: "green" }} />
        <Typography sx={{ ml: 1 }}>Create Task</Typography>
      </div>

      {iswaiting === false ? (
        <div className="mt-3">
          {taskdata.length > 0 ? (
            taskdata.map((task, i) => (
              <div className="row">
                <div
                  className="col-12 pt-2"
                  role="button"
                  tabIndex="0"
                  style={{
                    paddingLeft: 0,
                    borderLeft: `3px solid ${getStatusColor(task.status)}`,
                    borderTopLeftRadius: 4,
                    borderBottomLeftRadius: 4,
                  }}
                >
                  <Menu
                    key="left"
                    direction="right"
                    align="center"
                    position="anchor"
                    viewScroll="auto"
                    menuButton={
                      <IconButton style={{ float: "right" }}>
                        <MoreVertIcon />
                      </IconButton>
                    }
                  >
                    <MenuItem onClick={() => handleopenEditDialog(task)}>
                      <ListItemIcon>
                        <Icon icon={editFill} width={24} height={24} />
                      </ListItemIcon>
                      <ListItemText
                        primary="Edit"
                        primaryTypographyProps={{
                          variant: "body2",
                        }}
                      />
                    </MenuItem>
                    <MenuItem onClick={() => handleopenDeleteDialog(task)}>
                      <ListItemIcon>
                        <Icon icon={trash2Outline} width={24} height={24} />
                      </ListItemIcon>
                      <ListItemText
                        primary="Delete"
                        primaryTypographyProps={{
                          variant: "body2",
                        }}
                      />
                    </MenuItem>
                  </Menu>
                  {task.detailVisible === true && (
                    <IconButton
                      style={{ float: "right" }}
                      onClick={() => handleVisibleDetail(false, task.task_id)}
                    >
                      <KeyboardArrowUpIcon size="30" />
                    </IconButton>
                  )}
                  {task.detailVisible === false && (
                    <IconButton
                      style={{ float: "right" }}
                      onClick={() => handleVisibleDetail(true, task.task_id)}
                    >
                      <KeyboardArrowDownOutlinedIcon size="large" />
                    </IconButton>
                  )}
                  {/* <Tooltip title={getStatusLabel(task.status)}>
                              <CircleIcon
                                // color={getStatusColor(task.status)}
                                style={{
                                  width: 10,
                                  height: 10,
                                  float: 'right',
                                  marginTop: 13,
                                  zIndex: 2,
                                  color: `${getStatusColor(task.status)}`
                                }}
                              />
                            </Tooltip> */}
                  <span>
                    <Typography
                      component="span"
                      className="pb-1 ps-2"
                      style={{ fontWeight: "bold" }}
                    >
                      {i + 1}. {task.task}
                    </Typography>
                  </span>

                  {/* ================================================= detail ===================================== */}

                  {task.detailVisible === true ? (
                    <div className="row align-items-center pb-1 pl-3">
                      <div className="col-lg-12 col-md-12 col-sm-12">
                        <Typography>{task.description}</Typography>
                        <Typography
                          style={{
                            color: `${getStatusColor(task.status)}`,
                            fontSize: 12,
                            fontWeight: "bold",
                          }}
                        >
                          <CircleIcon
                            // color={getStatusColor(task.status)}
                            style={{
                              width: 10,
                              height: 10,
                              marginRight: 5,
                              color: `${getStatusColor(task.status)}`,
                            }}
                          />
                          {task.status}
                        </Typography>
                        <Typography>{assignee(task.members)}</Typography>
                      </div>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
                <Divider />
              </div>
            ))
          ) : (
            <div className="col-12 mt-5">
              <img src={noTask} alt="no task" style={{ margin: "auto" }} />
              <Typography
                style={{
                  textAlign: "center",
                  paddingLeft: 50,
                  paddingTop: 10,
                }}
              >
                No Task Found
              </Typography>
            </div>
          )}
        </div>
      ) : (
        <Sekeleton totalTask={taskdata.length} />
      )}

      {/* ============================================== Add Project component========================= */}
      <Dialog open={openAddDialog} onClose={handleCloseDialog}>
        <DialogContent>
          <AddTask handleAddTask={handleAddTask} />
        </DialogContent>
      </Dialog>
      <Dialog open={openEditDialog} onClose={handleCloseDialog}>
        <DialogContent>
          <EditTask
            handleEditTask={handleEditTask}
            taskId={rowData.task_id}
            handleCloseDialog={handleCloseDialog}
          />
        </DialogContent>
      </Dialog>
      <Dialog open={openDeleteDialog} onClose={handleCloseDialog}>
        <DialogTitle>Are you sure you want to delete this task ?</DialogTitle>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button onClick={() => handleDeleteTask(rowData.task_id)}>
            Yes, Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
    // </Page>
  );
}
