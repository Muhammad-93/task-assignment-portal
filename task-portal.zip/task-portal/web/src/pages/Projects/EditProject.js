import {
  Container,
  Button,
  Grid,
  IconButton,
  Typography,
  TextField,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useSnackbar } from "notistack";
import Chip from "@mui/material/Chip";
import Autocomplete from "@mui/material/Autocomplete";
import { team_listing } from "../../DAL/Team";
import { edit_project, project_detail } from "../../DAL/Project";

export default function EditProject(props) {
  const navigate = useNavigate();
  const { id } = useParams();
  const { enqueueSnackbar } = useSnackbar();
  const [team, setTeam] = useState([]);
  const [input, setInput] = useState({
    name: "",
    description: "",
    start_date: "",
    end_date: "",
    members: [],
  });

  console.log(id, "props id");

  const handleInputs = (e) => {
    setInput({ ...input, [e.target.id]: e.target.value });
  };
  const handlemembers = (event, value) => {
    console.log(event, value);
    setInput({ ...input, members: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(input, "inputs");
    const postData = {
      project_name: input.name,
      description: input.description,
      start_date: input.start_date,
      end_date: input.end_date,
      team_members: input.members,
    };
    const result = await edit_project(postData, id);
    if (result.code === 200) {
      navigate(-1);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
    }
  };

  const getProjectDetail = async () => {
    const result = await project_detail(id);
    // console.log(result.team);
    if (result.code === 200) {
      console.log(result.project[0].team_members, "result member");
      // setTeam(result.team);
      const teamMembers = result.project[0].team_members.map((x, i) => {
        let _arr = JSON.parse(x);
        return _arr;
      });
      console.log(teamMembers, "ndcujk");
      setInput({
        ...input,
        name: result.project[0].project_name,
        start_date: result.project[0].start_date.substring(0, 10),
        end_date: result.project[0].end_date.substring(0, 10),
        description: result.project[0].description,
        members: teamMembers,
      });
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
    }
  };

  const getTeamListing = async () => {
    const result = await team_listing();
    console.log(result.team);
    if (result.code === 200) {
      setTeam(result.team);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
    }
  };

  useEffect(() => {
    getProjectDetail();
    getTeamListing();
  }, []);

  return (
    <Container maxWidth="sm">
      <IconButton onClick={() => navigate(-1)}>
        <ArrowBackIcon />
      </IconButton>
      <Typography textAlign="center" variant="h4">
        Edit Project{" "}
      </Typography>
      <form onSubmit={handleSubmit}>
        <Grid spacing={2} container>
          <Grid item xs={12}>
            <TextField
              autoFocus
              fullWidth
              required
              margin="dense"
              value={input.name}
              onChange={handleInputs}
              id="name"
              label="Project Name"
              type="text"
              variant="outlined"
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              id="start_date"
              required
              label="Start Date"
              value={input.start_date}
              onChange={handleInputs}
              type="date"
              defaultValue="2017-05-24"
              fullWidth
              InputLabelProps={{
                shrink: true,
              }}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              id="end_date"
              label="End Date"
              required
              value={input.end_date}
              onChange={handleInputs}
              type="date"
              defaultValue="2017-05-24"
              fullWidth
              InputLabelProps={{
                shrink: true,
              }}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              autoFocus
              fullWidth
              required
              margin="dense"
              value={input.description}
              onChange={handleInputs}
              id="description"
              label="Description"
              type="text"
              variant="outlined"
              multiline
              rows={5}
            />
          </Grid>
          <Grid item xs={12}>
            <Autocomplete
              multiple
              id="tags-outlined"
              value={input.members}
              options={team}
              getOptionLabel={(option) => option.name}
              isOptionEqualToValue={(option, value) => option.id === value.id}
              onChange={(event, value) => handlemembers(event, value)}
              filterSelectedOptions
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Select Team Members"
                  // placeholder="Favorites"
                />
              )}
            />
          </Grid>

          <Grid mt={2} item xs={12} style={{ textAlign: "center" }}>
            <Button variant="contained" type="submit">
              Update
            </Button>
            <Button
              variant="contained"
              type="submit"
              className="ms-2"
              color="error"
              onClick={() => navigate("/project")}
            >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </form>
    </Container>
  );
}
