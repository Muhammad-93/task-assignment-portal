import {
  Container,
  Button,
  Grid,
  IconButton,
  Typography,
  TextField,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useSnackbar } from "notistack";
import Chip from "@mui/material/Chip";
import Autocomplete from "@mui/material/Autocomplete";
import { team_listing } from "../../DAL/Team";
import { add_project } from "../../DAL/Project";

export default function AddProject() {
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const [team, setTeam] = useState([]);
  const [input, setInput] = useState({
    name: "",
    description: "",
    start_date: "",
    end_date: "",
    members: [],
  });

  const handleInputs = (e) => {
    setInput({ ...input, [e.target.id]: e.target.value });
  };
  const handlemembers = (event, value) => {
    console.log(event, value);
    setInput({ ...input, members: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(input, "inputs");
    const postData = {
      project_name: input.name,
      description: input.description,
      start_date: input.start_date,
      end_date: input.end_date,
      team_members: input.members,
    };
    const result = await add_project(postData);
    if (result.code === 200) {
      navigate(-1);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
    }
  };

  const getTeamListing = async () => {
    const result = await team_listing();
    console.log(result.team);
    if (result.code === 200) {
      setTeam(result.team);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
    }
  };

  useEffect(() => {
    getTeamListing();
  }, []);

  return (
    <Container maxWidth="sm">
      <IconButton onClick={() => navigate(-1)}>
        <ArrowBackIcon />
      </IconButton>
      <Typography textAlign="center" variant="h4">
        Add Project{" "}
      </Typography>
      <form onSubmit={handleSubmit}>
        <Grid spacing={2} container>
          <Grid item xs={12}>
            <TextField
              autoFocus
              fullWidth
              required
              margin="dense"
              value={input.name}
              onChange={handleInputs}
              id="name"
              label="Project Name"
              type="text"
              variant="outlined"
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              id="start_date"
              label="Start Date"
              required
              value={input.start_date}
              onChange={handleInputs}
              type="date"
              defaultValue="2017-05-24"
              fullWidth
              InputLabelProps={{
                shrink: true,
              }}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              id="end_date"
              label="End Date"
              required
              value={input.end_date}
              onChange={handleInputs}
              type="date"
              defaultValue="2017-05-24"
              fullWidth
              InputLabelProps={{
                shrink: true,
              }}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              autoFocus
              fullWidth
              margin="dense"
              required
              value={input.description}
              onChange={handleInputs}
              id="description"
              label="Description"
              type="text"
              variant="outlined"
              multiline
              rows={5}
            />
          </Grid>
          <Grid item xs={12}>
            <Autocomplete
              multiple
              id="tags-outlined"
              options={team}
              getOptionLabel={(option) => option.name}
              onChange={(event, value) => handlemembers(event, value)}
              filterSelectedOptions
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Select Team Members"
                  // placeholder="Favorites"
                />
              )}
            />
          </Grid>

          <Grid mt={2} item xs={12} style={{ textAlign: "center" }}>
            <Button variant="contained" type="submit">
              Add Project
            </Button>
          </Grid>
        </Grid>
      </form>
    </Container>
  );
}
