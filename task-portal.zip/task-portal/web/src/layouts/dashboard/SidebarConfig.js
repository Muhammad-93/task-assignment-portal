import { Icon } from "@iconify/react";
import pieChart2Fill from "@iconify/icons-eva/pie-chart-2-fill";
import barchartfill from "@iconify/icons-eva/bar-chart-fill";
import peopleFill from "@iconify/icons-eva/people-fill";
import shoppingBagFill from "@iconify/icons-eva/shopping-bag-fill";
import fileTextFill from "@iconify/icons-eva/file-text-fill";
import lockFill from "@iconify/icons-eva/lock-fill";
import personAddFill from "@iconify/icons-eva/person-add-fill";
import alertTriangleFill from "@iconify/icons-eva/alert-triangle-fill";
import InventoryIcon from "@mui/icons-material/Inventory";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import ReceiptIcon from "@mui/icons-material/Receipt";
import SettingsIcon from "@mui/icons-material/Settings";

// ----------------------------------------------------------------------

const getIcon = (name) => <Icon icon={name} width={22} height={22} />;

const sidebarConfig = [
  // {
  //   title: "dashboard",
  //   path: "/dashboard",
  //   icon: getIcon(pieChart2Fill),
  // },
  {
    title: "Dashboard",
    path: "/dashboard",
    icon: <InventoryIcon width={22} height={22} />,
  },
  {
    title: "Projects",
    path: "/project",
    icon: <AccountBalanceWalletIcon width={22} height={22} />,
  },
  {
    title: "Team",
    path: "/team",
    icon: <ReceiptIcon width={22} height={22} />,
  },
  // {
  //   title: "settings",
  //   path: "/settings",
  //   icon: <SettingsIcon width={22} height={22} />,
  // },
  // {
  //   title: "support",
  //   path: "/support",
  //   icon: getIcon(pieChart2Fill),
  // },
];

export default sidebarConfig;
