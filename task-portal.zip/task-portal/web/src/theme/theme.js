export const color_palette = {
    primary: "#1961de",
    secondary: "#ffff",
  };
  
  export const app_logo = "";