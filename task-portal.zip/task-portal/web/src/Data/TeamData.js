export const TeamData=[
    {
        name: "Bilal Ahmed Abbasi",
        email: "babbasi38@gmail.com",
        phone: "3456",
        department: "3456",
        role: 1
      },
      {
        name: "Bilal Ahmed Abbasi",
        email: "babbasi38@gmail.com",
        phone: "3456",
        department: "3456",
        role: 1
      },
      {
        name: "Bilal Ahmed Abbasi",
        email: "babbasi38@gmail.com",
        phone: "3456",
        department: "3456",
        role: 1
      },
];