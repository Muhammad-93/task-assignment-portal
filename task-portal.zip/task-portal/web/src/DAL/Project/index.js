import { invokeApi } from "../../bl_libs/invokeApi";

export const project_listing = async () => {
  const requestObj = {
    path: `project/`,
    method: "GET",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
  };
  return invokeApi(requestObj);
};

export const add_project = async (data) => {
  const requestObj = {
    path: `project/add`,
    method: "POST",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
    postData: data,
  };
  return invokeApi(requestObj);
};

export const project_detail = async (id) => {
  const requestObj = {
    path: `project/${id}`,
    method: "GET",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
  };
  return invokeApi(requestObj);
};

export const edit_project = async (data, id) => {
  const requestObj = {
    path: `project/edit/${id}`,
    method: "PUT",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
    postData: data,
  };
  return invokeApi(requestObj);
};

export const delete_project = async (id) => {
  const requestObj = {
    path: `project/delete/${id}`,
    method: "DELETE",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
  };
  return invokeApi(requestObj);
};
