import { invokeApi } from "../../bl_libs/invokeApi";

export const task_listing = async (id) => {
  const requestObj = {
    path: `project/task/${id}`,
    method: "GET",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
  };
  return invokeApi(requestObj);
};

export const add_task = async (data) => {
  const requestObj = {
    path: `project/task/add`,
    method: "POST",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
    postData: data,
  };
  return invokeApi(requestObj);
};

export const task_detail = async (id) => {
  const requestObj = {
    path: `project/task_detail/${id}`,
    method: "GET",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
  };
  return invokeApi(requestObj);
};

export const edit_task = async (data, id) => {
  const requestObj = {
    path: `project/task/edit/${id}`,
    method: "PUT",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
    postData: data,
  };
  return invokeApi(requestObj);
};

export const delete_task = async (id) => {
  const requestObj = {
    path: `project/task/delete/${id}`,
    method: "DELETE",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
  };
  return invokeApi(requestObj);
};
