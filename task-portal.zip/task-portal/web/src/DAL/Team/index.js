import { invokeApi } from "../../bl_libs/invokeApi";

export const team_listing = async () => {
  const requestObj = {
    path: `team/`,
    method: "GET",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
  };
  return invokeApi(requestObj);
};

export const add_team = async (data) => {
  const requestObj = {
    path: `team/add`,
    method: "POST",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
    postData: data,
  };
  return invokeApi(requestObj);
};

export const team_detail = async (id) => {
  const requestObj = {
    path: `team/${id}`,
    method: "GET",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
  };
  return invokeApi(requestObj);
};

export const edit_team = async (data, id) => {
  const requestObj = {
    path: `team/edit/${id}`,
    method: "PUT",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
    postData: data,
  };
  return invokeApi(requestObj);
};

export const delete_team = async (id) => {
  const requestObj = {
    path: `team/delete/${id}`,
    method: "DELETE",
    headers: {
      Authorization: localStorage.getItem("token"),
    },
  };
  return invokeApi(requestObj);
};
