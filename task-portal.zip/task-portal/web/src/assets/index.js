// App logo undraw_no_data_re_kwbl
export { default as appLogoIcon } from "./images/app_logo.png";
export { default as paella } from "./images/paella.jpg";
export { default as noTask } from "./images/undraw_no_data_re_kwbl.svg";
