// here we add all base urls and keys

// Base URLS
export const baseUri = "https://taskportal-backend.herokuapp.com/";
// export const baseUri = "http://localhost:5000/";

// Keys
