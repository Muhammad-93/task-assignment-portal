import React, { useState } from "react";
import Drawer from "@mui/material/Drawer";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import SendIcon from "@mui/icons-material/Send";
import SaveAltIcon from "@mui/icons-material/SaveAlt";
import {
  Container,
  Stack,
  TableContainer,
  Card,
  Table,
  Button,
  Grid,
  IconButton,
  Typography,
} from "@mui/material";

export default function Backup({ openDrawer, ClosetoggleDrawer }) {
  return (
    <>
      <Drawer
        anchor="bottom"
        open={openDrawer}
        onClose={ClosetoggleDrawer}
        PaperProps={{
          sx: { height: 280 },
        }}
      >
        <Container>
          <Grid spacing={2} container>
            <Grid item xs={12} style={{ marginTop: 10 }}>
              <Typography variant="h6">Backup Options</Typography>
            </Grid>
            <Grid item xs={12} style={{ marginTop: 10 }}>
              <Button
                variant="outlined"
                fullWidth
                onClick={() => toggleDrawer()}
                startIcon={<ContentCopyIcon />}
              >
                Copy to Clipboard
              </Button>
            </Grid>
            <Grid item xs={12} style={{ marginTop: 10 }}>
              <Button
                variant="outlined"
                fullWidth
                onClick={() => toggleDrawer()}
                startIcon={<SaveAltIcon />}
              >
                Save Text File
              </Button>
            </Grid>
            <Grid item xs={12} style={{ marginTop: 10 }}>
              <Button
                variant="outlined"
                fullWidth
                onClick={() => toggleDrawer()}
                startIcon={<SendIcon />}
              >
                Send Over Email
              </Button>
            </Grid>
          </Grid>
        </Container>
      </Drawer>
    </>
  );
}
