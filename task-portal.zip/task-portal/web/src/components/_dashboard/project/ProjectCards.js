import * as React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import { Typography, ListItemText, Button } from "@mui/material";
import { paella } from "../../../assets";
import { IconButton } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogTitle from "@mui/material/DialogTitle";
import { Menu, MenuItem } from "@szhsin/react-menu";
import "@szhsin/react-menu/dist/index.css";
import { Link, Link as RouterLink, useNavigate } from "react-router-dom";
function ProjectCards({ project, deleteProject }) {
  const { id, project_name } = project;
  const navigate = useNavigate();
  const [opendialog, setOpenDialog] = React.useState(false);
  // const { id, name, cover } = project;

  const handleOpenDialig = (data) => {
    setOpenDialog(true);
    setProjectData(data);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };
  return (
    <>
      <Card sx={{ maxWidth: 345 }}>
        <Menu
          key="left"
          direction="right"
          align="center"
          position="anchor"
          viewScroll="auto"
          menuButton={
            <IconButton
              style={{
                zIndex: 9,
                top: 10,
                right: 9,
                position: "absolute",
              }}
            >
              <MoreVertIcon
                style={{
                  border: "1px solid black",
                  borderRadius: "50%",
                  color: "black",
                }}
              />
            </IconButton>
          }
        >
          <MenuItem
            onClick={() => navigate(`/project/edit_project/${id}`)}
            //   props.history.push({
            //     pathname: `/projects/edit_project/${x._id}`,
            //   })
            // }
            sx={{ color: "text.secondary" }}
          >
            {/* <ListItemIcon>
                <Icon icon={editFill} width={24} height={24} />
              </ListItemIcon> */}
            <ListItemText
              primary="Edit"
              primaryTypographyProps={{ variant: "body2" }}
            />
            {/* Edit */}
          </MenuItem>
          <MenuItem
            onClick={() => handleOpenDialig(project)}
            sx={{ color: "text.secondary" }}
          >
            {/* Delete */}
            {/* <ListItemIcon>
                <Icon icon={trash2Outline} width={24} height={24} />
              </ListItemIcon> */}
            <ListItemText
              primary="Delete"
              primaryTypographyProps={{ variant: "body2" }}
            />
          </MenuItem>
        </Menu>
        <CardMedia
          component="img"
          height="170"
          image={paella}
          alt="green iguana"
          style={{ cursor: "pointer" }}
          onClick={() => navigate(`/project/task/${id}`, { state: project })}
        />
        <CardContent>
          <Typography
            gutterBottom
            variant="h5"
            component="div"
            style={{ cursor: "pointer" }}
            onClick={() => navigate(`/project/task/${id}`, { state: project })}
          >
            {project_name}
          </Typography>
          {/* <Typography variant="body2" color="text.secondary">
            Lizards are a widespread group of squamate reptiles, with over 6,000
            species, ranging across all continents except Antarctica
          </Typography> */}
        </CardContent>
      </Card>
      <Dialog open={opendialog} onClose={handleCloseDialog}>
        <DialogTitle>
          Are you sure you want to delete this project ?
        </DialogTitle>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button onClick={() => deleteProject(id)}>Yes, Delete</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
export default ProjectCards;
