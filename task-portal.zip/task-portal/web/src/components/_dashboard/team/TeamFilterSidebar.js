import PropTypes from "prop-types";
import { useState } from "react";
import { Icon } from "@iconify/react";
import closeFill from "@iconify/icons-eva/close-fill";
import roundClearAll from "@iconify/icons-ic/round-clear-all";
import roundFilterList from "@iconify/icons-ic/round-filter-list";
// material
import {
  Box,
  Stack,
  Button,
  Drawer,
  Divider,
  Checkbox,
  FormGroup,
  IconButton,
  Typography,
  FormControlLabel,
  TextField,
} from "@mui/material";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
//
import Scrollbar from "../../Scrollbar";

// ----------------------------------------------------------------------

TeamFilterSidebar.propTypes = {
  isOpenFilter: PropTypes.bool,
  onResetFilter: PropTypes.func,
  onOpenFilter: PropTypes.func,
  onCloseFilter: PropTypes.func,
  formik: PropTypes.object,
};

export default function TeamFilterSidebar({
  isOpenFilter,
  onResetFilter,
  onOpenFilter,
  onCloseFilter,
}) {
  return (
    <>
      <div style={{ display: "flex" }}>
        <Button
          disableRipple
          color="inherit"
          endIcon={<Icon icon={roundFilterList} />}
          onClick={onOpenFilter}
        >
          Filters&nbsp;
        </Button>
      </div>
      <Drawer
        anchor="right"
        open={isOpenFilter}
        onClose={onCloseFilter}
        PaperProps={{
          sx: { width: 280, border: "none", overflow: "hidden" },
        }}
      >
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          sx={{ px: 1, py: 2 }}
        >
          <Typography variant="subtitle1" sx={{ ml: 1 }}>
            Filters
          </Typography>
          <IconButton onClick={onCloseFilter}>
            <Icon icon={closeFill} width={20} height={20} />
          </IconButton>
        </Stack>

        <Divider />

        <Scrollbar>
          <Stack spacing={3} sx={{ p: 3 }}>
            <div>
              <TextField label="Wallet Name" fullWidth autoFocus type="text" />
            </div>

            <div>
              <TextField label="Wallet Type" fullWidth type="text" />
            </div>

            <div>
              <TextField
                label="Present Coin Equity : USD"
                fullWidth
                type="text"
              />
            </div>
          </Stack>
        </Scrollbar>

        <Box sx={{ pl: 3, pr: 3, pt: 2 }}>
          <Button
            fullWidth
            size="large"
            type="submit"
            color="inherit"
            variant="outlined"
            onClick={onCloseFilter}
            startIcon={<FilterAltIcon />}
          >
            Filter
          </Button>
        </Box>

        <Box sx={{ pl: 3, pr: 3, pt: 3, pb: 1 }}>
          <Button
            fullWidth
            size="large"
            type="submit"
            color="inherit"
            variant="outlined"
            onClick={onResetFilter}
            startIcon={<Icon icon={roundClearAll} />}
          >
            Clear All
          </Button>
        </Box>
      </Drawer>
      {/* </Form> */}
      {/* </FormikProvider> */}
    </>
  );
}
