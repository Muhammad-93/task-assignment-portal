import PropTypes from "prop-types";
// material
import { visuallyHidden } from "@mui/utils";
import {
  Box,
  Checkbox,
  TableRow,
  TableCell,
  TableHead,
  TableSortLabel,
} from "@mui/material";
import { useNavigate } from "react-router-dom";

// ----------------------------------------------------------------------

TeamListHead.propTypes = {
  headLabel: PropTypes.array,
};

export default function TeamListHead({ headLabel }) {
  const navigate = useNavigate();
  return (
    <TableHead>
      {headLabel.map((headCell) => (
        <TableRow
        // hover
        // style={{ cursor: "pointer" }}
        // onClick={() => navigate("/wallet_detail")}
        >
          <TableCell>{headCell.name}</TableCell>
          <TableCell>{headCell.email}</TableCell>
          <TableCell>{headCell.role}</TableCell>
          <TableCell>{headCell.actionButton}</TableCell>
        </TableRow>
      ))}
    </TableHead>
  );
}
