import {
  Container,
  Button,
  Grid,
  IconButton,
  Typography,
  TextField,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useSnackbar } from "notistack";
import Chip from "@mui/material/Chip";
import Autocomplete from "@mui/material/Autocomplete";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { team_listing } from "../../../DAL/Team";
import { task_detail } from "../../../DAL/Task";

export default function AddTask({ handleEditTask, taskId, handleCloseDialog }) {
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const [team, setTeam] = useState([]);
  const [input, setInput] = useState({
    name: "",
    description: "",
    status: "",
    members: 0,
  });

  const handleInputs = (e) => {
    setInput({ ...input, [e.target.id]: e.target.value });
  };
  const handlemembers = (event, value) => {
    console.log(event, value);
    setInput({ ...input, members: value.id });
  };

  const handleChange = (event) => {
    setInput({ ...input, status: event.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(input, "inputs");
    handleEditTask(input, taskId);
    // const postData = {
    //   name: input.name,
    //   description: input.description,
    //   team_id: input.members,
    // };
    //   const result = await add_project(postData);
    //   if (result.code === 200) {
    //     navigate(-1);
    //   } else {
    //     enqueueSnackbar(result.message, { variant: "error" });
    //   }
  };

  const getTeamListing = async () => {
    const result = await team_listing();
    console.log(result.team);
    if (result.code === 200) {
      setTeam(result.team);
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
    }
  };

  const getTaskDetail = async () => {
    const result = await task_detail(taskId);
    console.log(result.team);
    if (result.code === 200) {
      //   setTeam(result.team);
      setInput({
        ...input,
        name: result.project[0].name,
        description: result.project[0].description,
        status: result.project[0].status,
        members: result.project[0].team_id,
      });
    } else {
      enqueueSnackbar(result.message, { variant: "error" });
    }
  };

  useEffect(() => {
    getTeamListing();
    getTaskDetail();
  }, []);

  return (
    <Container>
      <Typography textAlign="center" variant="h4">
        Update Task{" "}
      </Typography>
      <form onSubmit={handleSubmit}>
        <Grid spacing={2} container>
          <Grid item xs={12}>
            <TextField
              autoFocus
              fullWidth
              required
              margin="dense"
              value={input.name}
              onChange={handleInputs}
              id="name"
              label="Task Title"
              type="text"
              variant="outlined"
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              fullWidth
              margin="dense"
              required
              value={input.description}
              onChange={handleInputs}
              id="description"
              label="Description"
              type="text"
              variant="outlined"
              multiline
              rows={5}
            />
          </Grid>
          <Grid item xs={12}>
            <Autocomplete
              id="tags-outlined"
              options={team}
              getOptionLabel={(option) => option.name}
              onChange={(event, value) => handlemembers(event, value)}
              filterSelectedOptions
              renderInput={(params) => (
                <TextField {...params} label="Assign to Team Member" />
              )}
            />
          </Grid>
          <Grid item xs={12}>
            <FormControl fullWidth required>
              <InputLabel id="demo-simple-select-label">Status</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="status"
                required
                value={input.status}
                label="Status"
                onChange={handleChange}
              >
                <MenuItem value={"Pending"}>Pending</MenuItem>
                <MenuItem value={"Complete"}>Complete</MenuItem>
                <MenuItem value={"Approve"}>Approve</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          <Grid mt={2} item xs={12} style={{ textAlign: "center" }}>
            <Button variant="contained" type="submit">
              Update
            </Button>
            <Button
              variant="contained"
              type="submit"
              className="ms-2"
              color="error"
              onClick={() => handleCloseDialog()}
            >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </form>
    </Container>
  );
}
